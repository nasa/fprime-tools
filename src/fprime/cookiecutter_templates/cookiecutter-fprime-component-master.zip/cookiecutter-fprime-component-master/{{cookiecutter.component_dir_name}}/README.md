# {{cookiecutter.component_name}} Component

{{cookiecutter.component_short_description}}

For full documentation, see [the SDD](docs/sdd.md)
