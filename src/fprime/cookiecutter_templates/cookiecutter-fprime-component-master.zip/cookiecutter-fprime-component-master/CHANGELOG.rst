Changelog
#########

Use cookiecutter's ``--checkout`` options to use a specific version.

v1.0 (2020-09-26)
-----------------

* Initial Release
